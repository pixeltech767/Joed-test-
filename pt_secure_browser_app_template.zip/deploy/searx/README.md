# Searx setup instructions
